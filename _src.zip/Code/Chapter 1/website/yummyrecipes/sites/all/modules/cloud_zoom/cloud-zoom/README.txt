1) Download the Zip file from http://www.professorcloud.com/mainsite/cloud-zoom.htm
2) Put the two source files (listed below) found in the Zip file into this folder...
     * cloud-zoom.1.0.2.min.js
     * cloud-zoom.css
