// $Id: README.txt,v 1.1 2009/10/06 01:38:55 webchick Exp $

The themes in this subdirectory are all used by the Drupal core testing
framework. They are not functioning themes that could be used on a real site
and are hidden in the administrative user interface.
